import setuptools

setuptools.setup(
    name="bank_classification",
    version="1.0.3",
    author="Mark Raasveldt",
    description="Bank classification helper",
    packages=['bank_classification'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
