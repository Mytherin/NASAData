import random
import numpy
import math

names = ['James', 'Mary', 'John', 'Patricia', 'Robert', 'Jennifer', 'Michael', 'Linda', 'William', 'Elizabeth', 'David', 'Barbara', 'Richard', 'Susan', 'Joseph', 'Jessica', 'Thomas', 'Sarah', 'Charles', 'Margaret', 'Christopher', 'Karen', 'Daniel', 'Nancy', 'Matthew', 'Lisa', 'Anthony', 'Betty', 'Donald', 'Dorothy', 'Mark', 'Sandra', 'Paul', 'Ashley', 'Steven', 'Kimberly', 'Andrew', 'Donna', 'Kenneth', 'Emily', 'George', 'Carol', 'Joshua', 'Michelle', 'Kevin', 'Amanda', 'Brian', 'Melissa', 'Edward', 'Deborah', 'Ronald', 'Stephanie', 'Timothy', 'Rebecca', 'Jason', 'Laura', 'Jeffrey', 'Helen', 'Ryan', 'Sharon', 'Jacob', 'Cynthia', 'Gary', 'Kathleen', 'Nicholas', 'Amy', 'Eric', 'Shirley', 'Stephen', 'Angela', 'Jonathan', 'Anna', 'Larry', 'Ruth', 'Justin', 'Brenda', 'Scott', 'Pamela', 'Brandon', 'Nicole', 'Frank', 'Katherine', 'Benjamin', 'Samantha', 'Gregory', 'Christine', 'Raymond', 'Catherine', 'Samuel', 'Virginia', 'Patrick', 'Debra', 'Alexander', 'Rachel', 'Jack', 'Janet', 'Dennis', 'Emma', 'Jerry', 'Carolyn', 'Tyler', 'Maria', 'Aaron', 'Heather', 'Henry', 'Diane', 'Jose', 'Julie', 'Douglas', 'Joyce', 'Peter', 'Evelyn', 'Adam', 'Joan', 'Nathan', 'Victoria', 'Zachary', 'Kelly', 'Walter', 'Christina', 'Kyle', 'Lauren', 'Harold', 'Frances', 'Carl', 'Martha', 'Jeremy', 'Judith', 'Gerald', 'Cheryl', 'Keith', 'Megan', 'Roger', 'Andrea', 'Arthur', 'Olivia', 'Terry', 'Ann', 'Lawrence', 'Jean', 'Sean', 'Alice', 'Christian', 'Jacqueline', 'Ethan', 'Hannah', 'Austin', 'Doris', 'Joe', 'Kathryn', 'Albert', 'Gloria', 'Jesse', 'Teresa', 'Willie', 'Sara', 'Billy', 'Janice', 'Bryan', 'Marie', 'Bruce', 'Julia', 'Noah', 'Grace', 'Jordan', 'Judy', 'Dylan', 'Theresa', 'Ralph', 'Madison', 'Roy', 'Beverly', 'Alan', 'Denise', 'Wayne', 'Marilyn', 'Eugene', 'Amber', 'Juan', 'Danielle', 'Gabriel', 'Rose', 'Louis', 'Brittany', 'Russell', 'Diana', 'Randy', 'Abigail', 'Vincent', 'Natalie', 'Philip', 'Jane', 'Logan', 'Lori', 'Bobby', 'Alexis', 'Harry', 'Tiffany', 'Johnny', 'Kayla']
marital_status = ['Married', 'Single', 'Living Together', 'Divorced', 'Widowed']
age_bounds = (20, 80)
yearly_income_bounds = (20000, 200000)
net_worth_bounds = (-100000,200000)
cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'Dallas', 'San Jose', 'Austin', 'San Francisco', 'Seattle', 'Denver', 'Washington', 'Boston', 'Detroit']
industry_sector = ['Mining', 'Construction', 'Manufacturing', 'Utilities', 'Wholesale trade', 'Retail trade', 'Transportation and warehousing', 'Computer technology', 'Financial activities', 'Professional and business services', 'Educational services', 'Health Care', 'Social Assistance', 'Leisure', 'Hospitality', 'Other services', 'Federal government', 'State and local government', 'Agriculture']
contract_type = ['Permanent', 'Temporary (>6 Months Remaining)', 'Temporary (<6 Months Remaining)', 'Contractor', 'Retired']
credit_score_bounds = (300, 850)
loan_amount_bounds = (50000, 400000)

city_income_factor = [2.5, 2.3, 1.2, 1, 1.2, 1.8, 1.6, 1.4, 1.8, 3, 2.5, 1.5, 1.8, 2.4, 1.2]
min_income = 20000
income_factors = [(30000, 0.5), (50000, 0.2), (70000, 0.15), (100000, 0.1), (200000, 0.05)]

low_income_industries = ['Educational services', 'Hospitality', 'State and local government','Manufacturing', 'Transportation and warehousing', 'Retail trade']
high_income_industries = ['Financial activities', 'Professional and business services', 'Health Care', 'Computer technology']
medium_income_industries = [x for x in industry_sector if x not in low_income_industries and x not in high_income_industries]

def random_list(input_list):
	return input_list[random.randint(0, len(input_list)-1)]

def random_bounds(bounds):
	return random.randint(bounds[0], bounds[1])

def random_list_weights(input_list, weights):
	random_value = random.random()
	current_weight = 0
	for i in range(len(weights)):
		current_weight += weights[i]
		if random_value < current_weight:
			return input_list[i]


def random_marital_status(age):
	if age < 30:
		return random_list_weights(marital_status, [0.1, 0.6, 0.2, 0.1, 0])
	if age < 40:
		return random_list_weights(marital_status, [0.2, 0.4, 0.25, 0.2, 0])
	if age < 50:
		return random_list_weights(marital_status, [0.25, 0.3, 0.2, 0.25, 0])
	if age < 60:
		return random_list_weights(marital_status, [0.35, 0.2, 0.15, 0.28, 0.02])
	if age < 70:
		return random_list_weights(marital_status, [0.4, 0.15, 0.15, 0.2, 0.1])
	return random_list_weights(marital_status, [0.35, 0.1, 0.2, 0.15, 0.2])

def random_income(city, age):
	# get the base income level
	income_factor = random_list_weights([x[0] for x in income_factors], [x[1] for x in income_factors])
	city_factor = numpy.sqrt(city_income_factor[cities.index(city)])
	if age < 65:
		age_factor = numpy.random.normal(1 + float(age - age_bounds[0]) / float(age_bounds[1]), scale=0.5)
	else:
		age_factor = 1
	base_income = income_factor * city_factor * age_factor
	base_income = max(base_income, min_income)
	return int(int(numpy.random.normal(base_income, scale=0.1*base_income) / 100) * 100)

def random_field(income):
	if income < 40000:
		low_income = 0.7
		medium_income = 0.2
		high_income = 0.1
	elif income > 100000:
		low_income = 0.1
		medium_income = 0.2
		high_income = 0.7
	else:
		low_income = 0.2
		medium_income = 0.6
		high_income = 0.2
	# first determine low, medium or high income industry
	weights = [low_income, medium_income, high_income]
	industries = [low_income_industries, medium_income_industries, high_income_industries]
	potential_industries = random_list_weights(industries, weights)
	# now pick an industry from the sector
	return random_list(potential_industries)

def random_net_worth(income, age, field, city, marital_status, contract_type):
	# average savings
	if field in high_income_industries:
		savings_factor = 0.1
	elif field in medium_income_industries:
		savings_factor = 0.08
	else:
		savings_factor = 0.06
	age_factor = age - age_bounds[0]
	# after 65 the age factor actually inverses because people eat into their savings (to retire)
	if age >= 65:
		age_factor = 65 - age_bounds[0] - (age - 65)
	# for people that are married, living together or widowed we subtract the cost of children by dividing the age factor by two
	if marital_status in ['Married', 'Living Together', 'Divorced', 'Widowed']:
		age_factor /= 2
	if marital_status in 'Divorced':
		savings_factor /= 2
	# subtract cost of living
	cost_of_living = 10000 * city_income_factor[cities.index(city)]
	base_net_worth = (income - cost_of_living) * (age_factor + 1) * savings_factor
	scale = base_net_worth * 0.5
	if contract_type == 'Contractor':
		scale *= 3
	if scale < 0:
		scale = -scale
	if scale == 0:
		scale = 1
	generated_net_worth = numpy.random.normal(base_net_worth, scale)
	# we discount the price of a house in the area, but only if age > 35
	# if age < 35, we subtract student loans, but only for high income industries
	if age < 35 and field in high_income_industries:
		generated_net_worth -= max(numpy.random.normal(40000, 30000), 0)
	# if age < 35 and in low_income_industry, we introduce credit card debt
	if age < 35 and field in low_income_industries:
		generated_net_worth -= max(numpy.random.normal(2000, 10000), 0)
	return int(int(generated_net_worth / 1000) * 1000)

def random_contract_type(field, age, income):
	if age < 30:
		weights = [0.1, 0.5, 0.3, 0.1, 0]
	elif age < 40:
		weights = [0.3, 0.3, 0.1, 0.2, 0]
	elif age < 50:
		weights = [0.35, 0.3, 0.1, 0.24, 0.01]
	elif age < 60:
		weights = [0.45, 0.25, 0.05, 0.25, 0.05]
	elif age < 70:
		weights = [0.45, 0.05, 0.05, 0.15, 0.3]
	else:
		weights = [0.15, 0.05, 0.05, 0.1, 0.7]
	if income > 100000:
		# really high income is more likely to do contract work
		weights[0] -= 0.05
		weights[1] -= 0.05
		weights[2] -= 0.05
		weights[3] += 0.15
	if field in high_income_industries:
		# high income industry more likely to have permanent position
		weights[0] += 0.1
		weights[1] -= 0.05
		weights[2] -= 0.05
	if field in ['Federal government', 'State and local government', 'Educational services']:
		# government jobs more likely to have permanent positions and no contract work
		weights[0] += 0.1 + weights[3]
		weights[1] -= 0.05
		weights[2] -= 0.05
		weights[3] = 0
	if sum(weights) < 1:
		weights[0] += 1 - sum(weights)
	return random_list_weights(contract_type, weights)

def random_credit_score(age, income, contract_type, marital_status, net_worth):
	if income > 100000:
		base_score = 700
	elif income > 50000:
		base_score = 550
	else:
		base_score = 400
	if net_worth < 0:
		if age < 30:
			base_score -= 50
		else:
			base_score -= 200
	elif net_worth > 100000:
		base_score += 100
	elif net_worth > 50000:
		base_score += 50
	if contract_type == 'Permanent':
		base_score += 50
	if marital_status == 'Married' or marital_status == 'Living Together':
		base_score += 50
	score = numpy.random.normal(base_score, 20)
	return int(int(score / 50) * 50)

def generate_person():
	name = random_list(names)
	city = random_list(cities)
	age = random_bounds(age_bounds)
	marital_status = random_marital_status(age)
	income = random_income(city, age)
	field = random_field(income)
	contract_type = random_contract_type(field, age, income)
	net_worth = random_net_worth(income, age, field, city, marital_status, contract_type)
	credit_score = random_credit_score(age, income, contract_type, marital_status, net_worth)
	return (name, city, age, marital_status, income, field, contract_type, net_worth, credit_score)
	
def get_test_set(count=1000):
	header = ['name', 'city', 'age', 'marital_status', 'income', 'field', 'contract_type', 'net_worth', 'credit_score']
	# generate 1000 people
	people = []
	for i in range(count):
		people.append(generate_person())
	result_dict = {}
	for i in range(len(header)):
		result_dict[header[i]] = numpy.array([x[i] for x in people])
	return result_dict


__all__ = ['get_test_set']
name = 'bank_classification'
